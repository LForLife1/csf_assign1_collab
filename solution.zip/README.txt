Computer System Fundamentals - Liam Finn and Trevor Black

Milestone 1: We met outside of class and discussed how we would implement the three functions, 
and then outside of class we split the workload. Liam did uint256_create_from_u32 and 
uint256_create, while Trevor did uint256_get_bits.


Milestone 2: We again started by discussing how each function should be implemented. Then, Trevor did
uint256_rotate_left and uint256_rotate_right. Liam worked on add negate and subtract, and then we worked
together on create and format hex together. We also wrote unit tests for the functions that we worked on.
